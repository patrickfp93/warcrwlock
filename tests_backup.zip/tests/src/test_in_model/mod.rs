pub mod only_structure;
pub mod with_into_impl;
pub mod with_generics;
pub mod generics_with_trait;